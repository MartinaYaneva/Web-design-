// Готов джаваскрип за дата
var mydate=new Date()
var year=mydate.getYear()
if (year < 1000)
year+=1900
var day=mydate.getDay()
var month=mydate.getMonth()+1
if (month<10)
month="0"+month
var daym=mydate.getDate()
if (daym<10)
daym="0"+daym
document.write("<small><font color='000000' face='Arial'><b>"+year+"/"+month+"/"+daym+"</b></font></small>")

function changeImg(id) {
    var img = document.getElementById("img");
    var btnContainer = document.getElementById("btnContainer");
    var btns = btnContainer.getElementsByClassName("button");

    for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function () {
            var current = document.getElementsByClassName("active");

            if (current.length > 0) {
                current[0].className = current[0].className.replace(" active", "");
            }

            this.className += " active";
      });
    }

    switch (id) {
        case 1:
            img.src = "stan.jpg";
            break;
        case 2:
            img.src = "stan1.jpg";
            break;
        case 3:
            img.src = "Stan-Lee.jpg";
            break }}